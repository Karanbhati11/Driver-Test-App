module.exports = (req, res) => {
  res.render("signup", { message: "" });
};
