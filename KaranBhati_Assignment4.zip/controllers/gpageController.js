const usermodel = require("../models/user");
const Cryptr = require("cryptr");
const cryptr = new Cryptr("myTotallySecretKey");
module.exports = async (req, res) => {
  // checking if user exists or not
  const user = await usermodel.findById(req.session.userInfo?.userId);

  if (user) {
    const decryptedString = cryptr.decrypt(user.License_No);
    user.License_No = decryptedString;
    res.render("G", { response: user, message: "" });
  } else {
    res.redirect("/");
  }

  console.log(user);
};
