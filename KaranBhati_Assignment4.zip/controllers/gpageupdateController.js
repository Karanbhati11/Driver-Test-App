const usermodel = require("../models/user");

module.exports = async (req, res) => {
  const { carMake, carModel, carYear, plateNumber } = req.body;

  // checking if userexists by userId
  const user = await usermodel.findById(req.session.userInfo.userId);
  if (
    carMake === "" ||
    carModel === "" ||
    carYear === "" ||
    plateNumber === ""
  ) {
    res.render("G", { response: user, message: "Please Enter all the Fields" });
  } else {
    // updating the user details
    const newUser = {
      car_details: {
        make: carMake,
        model: carModel,
        year: carYear,
        platno: plateNumber,
      },
    };
    await usermodel
      .findByIdAndUpdate(req.session.userInfo.userId, newUser)
      .then((response) => {
        console.log(response);
        res.redirect("/");
      })
      .catch((err) => {
        console.log("error" + err);
      });
  }
};
